
# JSSATE Bangalore Website

Official website for JSS Academy of Technical Education, Bangalore.

## Sections
- About
- Events
- Gallery
- Contact

Built with simple HTML and CSS. Hosted on GitHub Pages.

## Deployment
Upload the files to a GitHub repository and enable GitHub Pages from the settings.

---
Created by Haridev.
